export const _App = Object.freeze({
    _URL: "http://localhost:51857/api/",// 'http://localhost:51857/api/',
    ContactController: "contact/",
    SaveContact:"SaveContact",
    GetContactList:"GetContactlist"
});