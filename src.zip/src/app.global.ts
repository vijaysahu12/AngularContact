export const GlobalVariable = Object.freeze({
    BASE_API_URL: 'http://localhost:51857/api/',
    GetContactList:"GetContactlist"
});